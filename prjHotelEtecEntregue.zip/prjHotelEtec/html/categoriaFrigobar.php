<?php include_once('include/superior.php');?>
    <div class="clear"></div>
    <div class="bannerOnda"></div>
    <div id="titlePages">Suíte com Frigobar</div>
    <div class="margim">


        <section class="container">
        
        <div class="load">
            <img src="../img/carFrigo.JPG" alt="">
            <img src="../img/carFrigo1.JPG" alt="">
            <img src="../img/carFrigo2.JPG" alt="">
            <img src="../img/carFrigo3.JPG" alt="">
            
        </div>


            <div id="produtoFinalFoto">
                <img src="" id="imgFrigobar">
            </div>
            <div id="produtoFinalTexto">
                <h1>Suíte com Frigobar</h1>	
                <p>As Suites com Frigobar também podem ser moldadas a sua necessidade, com cama de casal, beliche, cama de solteiro e berço. Por ter um amplo espaço, acomoda bem as famílias maiores. Para aquele que precisa viajar a trabalho, estando sozinho ou acompanhado, é a nossa categoria com um preço bem atrativo. A suite conta com o diferencial do frigobar, que não é cobrado por diárias e sim pelo preço único. Os hóspedes podem abastecêlo e consumir os produtos que levar no apartamento. Também é um diferencial para aqueles que precisam sempre ter medicações que precisam ser conservadas</p>

                <h1>Descrição</h1>	
                <p>Cama de Casal / Solteiro / Beliche / Berço, Ar Condicionado, Varanda, Banheiro Privativo com Ducha com Aquecimento Central, TV de LCD de 24 polegadas, armário, frigobar e wireless.</p>

                <h1 id="obsevacoesQuarto">Observações</h1>	
                <p>Lotação máxima: 6 pessoas.</p>
            </div>

        <div class="clear"></div>

        </section>

    </div>

<script src = "../js/carrouselFrigobar.js"></script>
<?php include_once('include/inferior.php');?>