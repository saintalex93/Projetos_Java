<?php include_once('include/superior.php');?>
      
    <div class="clear"></div>
    <div class="bannerOnda"></div>
    <div id="titlePages">Categorias</div>
    <div class="margim">

	<main class="main">
	
  
	    <section class="container">
		
			<div class="quartoFoto">
				<h2 class="titleCategory">Suíte Standard</h2>
				<a href="categoriaStandard.php">
				<img src="../img/suiteStandardAcom.JPG" alt=""></a>
			</div>
			
			
			<div class="quartoFoto">
				<h2 class="titleCategory">Suíte com Figobar</h2>
				<a href="categoriaFrigobar.php">
				<img src="../img/suiteFrigobarAcom.JPG" alt=""></a>
			</div>
			
			
			<div class="quartoFoto">
				<h2 class="titleCategory">Suíte Especial</h2>

				<a href="categoriaEspecial.php">
				<img src="../img/suiteEspecialAcm.JPG" alt=""></a>
			</div>
			
			<div class="clear"></div>
		</section>
   
    </main>
</div>
    
    
<?php include_once('include/inferior.php');?>