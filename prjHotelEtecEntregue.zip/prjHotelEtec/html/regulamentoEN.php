<?php include_once('include/superiorEN.php');?>
<div class="clear"></div>
<div class="bannerOnda">

</div>
<div id="titlePages">Schedule and Regulation</div>
<div class="margim">

    <main class="main">
        <div class="rules">
            <!--h1 class="title">Regulamento</h1-->

            <h2 id="timeRules">Schedules:</h2>
            <table id="tableRules">
                <tr>
                    <th>Reception (Number 9)</th>
                    <th>24 Horas</th>
                </tr>

                <tr>
                    <td>Breakfast</td>
                    <td>08:00 AM to 10:00 AM</td>
                </tr>
                <tr>
                    <td>Lunch</td>
                    <td>12:30 PM to 02:00 PM</td>
                </tr>
                <tr>
                    <td>Dinner</td>
                    <td>07:00 PM to 08:30 PM</td>
                </tr>
                <tr>
                    <td>Snacks and portions requests</td>
                    <td>09:00 AM to 08:30 PM</td>
                </tr>
                <tr>
                    <td>Pool bar</td>
                    <td>10:00 AM to 08:00 PM</td>
                </tr>
                <tr>
                    <td>Pool</td>
                    <td>10:00 AM to 10:00 PM</td>
                </tr>
                <tr>
                    <td>Games room and TV room</td>
                    <td>10:00 AM to 10:00 PM</td>
                </tr>
            </table>
            <br>

            <div id="rulesList">

                <ul>
                    <li>The Hotel do not will be resposible for any objects or money get left into apartments and vehicles.</li>
                    <li>The apartments are exclusive for guests and visitor are note allowed.</li>
                    <li>The prolongation of the stay after the end of hotel, it’s possible  after reception consult.</li>
                    <li>The bed clothes  will be changed every other day.The request for change this request, out of the period can will be extra charge.</li>
                    <li>Leave the Keys in reception until 10:00 AM for the bedroom cleaning. After this time the apartment won’t be  cleaned.</li>
                    <li>Inform previously leave, for billing that will be finished through the return of the keys, remote control and appartments check.</li>
                    <li>The phone of the apartments has access a local and intercity calls.</li>
                    <li>The mothers scullery is exclusive for prepare food for children. The keys are  in the reception.</li>
                   <li> It’s not allowed the of use eletric iron in the apartments.</li>
                   <li> It’s not allowed noise before 10:00 AM and after 10:00PM.</li>
                   <li> It’s not allowed use the towels of apartmens for pool, beaches or tours.</li>
                   <li> It’s not allowed hang clothes to dry on window , hall balcony  or  apartments doors.</li>
                   <li> Animals are not allowed in hotel dependences.</li>
                   <li> It’s no allowed to came and remain the restaurant, games room and tv room with bath clothes.</li>
                   <li> Because of hygiene reasons and maintenance water and equipaments, is forbidden the use of oils, suntan lotion or creams in the pool.</li>
                   <li> It’s forbidden the billiard game for younger than 16 years old, except only followed by parents or responsibles.</li>
                   <li> The barbecue grill of the bar is exclusive for closed events.</li>
                </ul>

                <h2 class="atencao">CAUTION:</h2>

                <ul>
                    <li>At the shower time we recomend open first the registre of cold water.</li>
                    <li>The voltage is 110 volts.</li>
                    <li>Turn off the lights, turn off ar-conditioner and tv before get out of apartment.</li>
                    <li>It’s forbidden take away food and drinks for pool area, snack bar and restaurants, except they were acquired on the hotel</li>

                </ul>

            </div>
        </div>
    </main>

   
</div>

    <?php include_once('include/inferior.php');?>
