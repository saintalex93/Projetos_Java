<?php include_once('include/superiorEN.php');?>
    <div class="clear"></div>
    <div class="bannerOnda"></div>
    <div id="titlePages">Suite with mini Fridge</div>
    <div class="margim">


        <section class="container">
        
        <div class="load">
            <img src="../img/carFrigo.JPG" alt="">
            <img src="../img/carFrigo1.JPG" alt="">
            <img src="../img/carFrigo2.JPG" alt="">
            <img src="../img/carFrigo3.JPG" alt="">
            
        </div>


            <div id="produtoFinalFoto">
                <img src="" id="imgFrigobar">
            </div>
            <div id="produtoFinalTexto">
                <h1>Suite with mini Fridge</h1>	
                <p>The suítes with mini fridge also  can be moldade with  your necessity, with double bed, bunk bed, single bed and baby crib. For having a big space, accommodates very well big family’s. For those that need work travel, being alone or with accompanist, This is our category with a good price atractive. The suite have the diferencial with mini fridge, that is don’t pay for daily but by for unique price. The guests can supply it and consumer the products that take in the apartament. Also is a diferenttial for those that need always have medicines that need conservation.</p>

                <h1>Description</h1>	
                <p>Double bed, single bed, bunk bed, baby crib, ar-condionater, balcony,  private bathroom with shower with central heating, TV LCD 24”, wardrobe, mini fridge and wireless</p>

                <h1 id="obsevacoesQuarto">Observation</h1>	
                <p>Max accommodation: 6 people.</p>
            </div>

        <div class="clear"></div>

        </section>

    </div>

<script src = "../js/carrouselFrigobar.js"></script>
<?php include_once('include/inferior.php');?>