<?php include_once('include/superior.php');?>

	<div class="clear"></div>
	<div class="bannerOnda" >

	</div>
	<div id="titlePages">Suite Especial</div>
	<div class="margim">
		<section class="container">
		
	 	<div class="load">
	 	
			<img src="../img/carEspec.JPG" alt="">
            <img src="../img/carEspec1.JPG" alt="">
            <img src="../img/carEspec2.JPG" alt="">
            <img src="../img/carEspec3.JPG" alt="">
            
        </div>

			<div id="produtoFinalFoto">
				<img src="" id="imgEspecial">
			</div>
			<div id="produtoFinalTexto">
				<h1>Suite Especial</h1>	
				<p>Com apenas 5 suites no hotel, a suite especial tem vista para o mar, sendo uma boa pedida para casais que desejam passar mais tempos juntos. Por acomodar apenas duas pessoas, tem um maior conforto e mais espaço.</p>

				<h1>Descrição</h1>	
				<p>Cama de casal Box King Size, TV de 28 polegadas, Ar Condicionado, Ventilador de Teto, Frigobar, secado de cabelo, banheiro privativo com ducha com aquecimento central, Poltrona com apoio para os pés, mesa com cadeiras, cadeiras na varanda e Wireless.</p>

				<h1 id="obsevacoesQuarto">Observações</h1>	
				<p>Acomodação máxima: 2 Pessoas.</p>
			</div>

			<div class="clear"></div>

		</section>

	</div>

<script src = "../js/carrouselEspecial.js"></script>

<?php include_once('include/inferior.php');?>