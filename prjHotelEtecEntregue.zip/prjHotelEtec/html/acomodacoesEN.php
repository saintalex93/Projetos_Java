<?php include_once('include/superiorEN.php');?>

      
    <div class="clear"></div>
    <div class="bannerOnda"></div>
    <div id="titlePages">Categories</div>
    <div class="margim">

	<main class="main">
	
  
	    <section class="container">
		
			<div class="quartoFoto">
				<h2 class="titleCategory">Standard Suite</h2>
				<a href="categoriaStandardEN.php">
				<img src="../img/suiteStandardAcom.JPG" alt=""></a>
			</div>
			
			
			<div class="quartoFoto">
				<h2 class="titleCategory">Suite with mini fridge</h2>
				<a href="categoriaFrigobarEN.php">
				<img src="../img/suiteFrigobarAcom.JPG" alt=""></a>
			</div>
			
			
			<div class="quartoFoto">
				<h2 class="titleCategory">Especial Suite</h2>

				<a href="categoriaEspecialEN.php">
				<img src="../img/suiteEspecialAcm.JPG" alt=""></a>
			</div>
			
			<div class="clear"></div>
		</section>
   
    </main>
</div>
    
    
<?php include_once('include/inferior.php');?>