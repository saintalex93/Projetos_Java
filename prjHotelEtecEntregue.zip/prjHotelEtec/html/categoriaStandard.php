<?php include_once('include/superior.php');?>

	<div class="clear"></div>
	<div class="bannerOnda" ></div>
	<div id="titlePages">Suite Standard</div>
	<div class="margim">


		<div class="clear"></div>
		<section class="container">

		<div class="load">
			<img src="../img/carStd.JPG" alt="">
			<img src="../img/carStd1.JPG" alt="">
			<img src="../img/carStd2.JPG" alt="">
			<img src="../img/carStd3.JPG" alt="">
			
		</div>
		
			<div id="produtoFinalFoto">
				<img src="" id="imgStandard">
			</div>
			<div id="produtoFinalTexto">
				<h1>Suite Standard</h1>	
				<p>As Suites Standards podem ser moldadas a sua necessidade, com cama de casal, beliche, cama de solteiro e berço. Por ter um amplo espaço, acomoda bem as famílias maiores. Para aquele que precisa viajar a trabalho, estando sozinho ou acompanhado, é a nossa categoria com um preço bem atrativo. </p>

				<h1>Descrição</h1>	
				<p>Cama de Casal / Solteiro / Beliche / Berço, Ar Condicionado, Varanda, Banheiro Privativo com Ducha com Aquecimento Central, TV de LCD de 24 polegadas, armário e wireless.</p>

				<h1 id="obsevacoesQuarto">Observações</h1>	
				<p>Lotação máxima: 6 pessoas.</p>
			</div>

			<div class="clear"></div>


		</section>


	</div>
    
<script src = "../js/carrouselStandard.js"></script>    
<?php include_once('include/inferior.php');?>