<footer>

    <div id="enderecoRodape">
        <i class="fa fa-map-marker" aria-hidden="true"></i> Rua Sapetuba, 6315 / Rua Paris, 117<br>
        Jardim Suarão, Itanhaém - SP <br>CEP: 11.740-000<br>
        <i class="fa fa-phone" aria-hidden="true"></i> (13) 3424-3398 / 
        <i class="fa fa-mobile" aria-hidden="true"></i> (11) 94721-2257<br>
        <i class="fa fa-envelope-o" aria-hidden="true"></i> contato@hotelclubeazuldomar.com.br<br>
    </div>

    <div class="clear"></div>

    <div id="copy"><p>Copyright © 2017</p></div>
    
<link href="https://fonts.googleapis.com/css?family=Overlock" rel="stylesheet">   
<script src="../js/menu.js"></script>
</footer>
    
