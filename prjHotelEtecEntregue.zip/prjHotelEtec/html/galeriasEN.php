<?php include_once('include/superiorEN.php');?>
     <div class="clear"></div>
    <div class="bannerOnda" >
        
    </div>
    <div id="titlePages">About Hotel!</div>
    <div class="margim">

    <section class="container">

	<main class="main">
		
		<div class="galerias">
		<!--h1 class="title">Conheça o Hotel!</h1-->
			<div class="galeriaSuperior">
			<div class="CaixaGaleria">
				<a href="galeriaLazerEN.php"><img src="../img/piscinaGaleria.JPG" alt=""></a>
				<h3>Recreation Area</h3>
			</div>
			<div class="CaixaGaleria">
				<a href="areaComumEN.php"><img src="../img/aereaPublicaGaleria.JPG" alt=""></a>
				<h3>Common Area</h3>

				
			</div>
			</div>
			<div class="galeriaInferior">
			<div class="CaixaGaleria">
				<a href="eventosEN.php"><img src="../img/eventosGaleria.JPG" alt=""></a>
				<h3>Events</h3>

				
			</div>
			<div class="CaixaGaleria">
				<a href="galeriaExternoEN.php"><img src="../img/hotelGalerias.JPG" alt=""></a>
				<h3>Extern Area</h3>

				
			</div>
			</div>
		</div>
		<div class="clear"></div>
	</main>

    </section>
</div>
    
<?php include_once('include/inferior.php');?>