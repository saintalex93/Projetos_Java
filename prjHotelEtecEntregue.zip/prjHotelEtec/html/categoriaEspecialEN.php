<?php include_once('include/superiorEN.php');?>


	<div class="clear"></div>
	<div class="bannerOnda" >

	</div>
	<div id="titlePages">Especial Suite</div>
	<div class="margim">
		<section class="container">
		
	 	<div class="load">
	 	
			<img src="../img/carEspec.JPG" alt="">
            <img src="../img/carEspec1.JPG" alt="">
            <img src="../img/carEspec2.JPG" alt="">
            <img src="../img/carEspec3.JPG" alt="">
            
        </div>

			<div id="produtoFinalFoto">
				<img src="" id="imgEspecial">
			</div>
			<div id="produtoFinalTexto">
				<h1>Especial Suite</h1>	
				<p>With just 5 suites in hotel, the especial suíte has view for the sea, being a good suggestion for couples that wishing spend some time together, with more confortable and more space for them.</p>

				<h1>Description</h1>	
				<p>Double bed box King Size, tv 28”, ar-conditionar, ceiling fan, mini fridge, hair dryer, private bathroom with shower with central heating, Armchair with support for foot, kitchen table, chair in balcony and wireless.</p>

				<h1 id="obsevacoesQuarto">Observation</h1>	
				<p>Maximo accommodation: 2 people.</p>
			</div>

			<div class="clear"></div>

		</section>

	</div>

<script src = "../js/carrouselEspecial.js"></script>

<?php include_once('include/inferior.php');?>