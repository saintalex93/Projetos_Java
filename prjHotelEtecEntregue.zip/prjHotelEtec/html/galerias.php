<?php include_once('include/superior.php');?>
     <div class="clear"></div>
    <div class="bannerOnda" >
        
    </div>
    <div id="titlePages">Conheça o Hotel!</div>
    <div class="margim">

    <section class="container">

	<main class="main">
		
		<div class="galerias">
		<!--h1 class="title">Conheça o Hotel!</h1-->
			<div class="galeriaSuperior">
			<div class="CaixaGaleria">
				<a href="galeriaLazer.php"><img src="../img/piscinaGaleria.JPG" alt=""></a>
				<h3>Lazer</h3>
			</div>
			<div class="CaixaGaleria">
				<a href="areaComum.php"><img src="../img/aereaPublicaGaleria.JPG" alt=""></a>
				<h3>Área Comum</h3>

				
			</div>
			</div>
			<div class="galeriaInferior">
			<div class="CaixaGaleria">
				<a href="eventos.php"><img src="../img/eventosGaleria.JPG" alt=""></a>
				<h3>Eventos</h3>

				
			</div>
			<div class="CaixaGaleria">
				<a href="galeriaExterno.php"><img src="../img/hotelGalerias.JPG" alt=""></a>
				<h3>Área Externa</h3>

				
			</div>
			</div>
		</div>
		<div class="clear"></div>
	</main>

    </section>
</div>
    
<?php include_once('include/inferior.php');?>