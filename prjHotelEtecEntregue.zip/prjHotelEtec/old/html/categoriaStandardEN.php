<?php include_once('include/superiorEN.php');?>

	<div class="clear"></div>
	<div class="bannerOnda" ></div>
	<div id="titlePages">Standard Suite</div>
	<div class="margim">


		<div class="clear"></div>
		<section class="container">

		<div class="load">
			<img src="../img/carStd.JPG" alt="">
			<img src="../img/carStd1.JPG" alt="">
			<img src="../img/carStd2.JPG" alt="">
			<img src="../img/carStd3.JPG" alt="">
			
		</div>
		
			<div id="produtoFinalFoto">
				<img src="" id="imgStandard">
			</div>
			<div id="produtoFinalTexto">
				<h1>Standard Suite</h1>	
				<p>The Standar suítes can be moldade with  your necessity, with double bed, bunk bed, single bed and baby crib. For having a big space, accommodates very well big family’s. For those that need work travel, being alone or with accompanist, this is our category with a good price atractive.</p>

				<h1>Description</h1>	
				<p>double bed, single bed, bunk bed, baby crib, ar-condionater, balcony,  private bathroom with shower with central heating, TV LCD 24”, wardrobe  and wireless</p>

				<h1 id="obsevacoesQuarto">Observation</h1>	
				<p>Max accommodation: 6 people.</p>
			</div>

			<div class="clear"></div>


		</section>


	</div>
    
<script src = "../js/carrouselStandard.js"></script>    
<?php include_once('include/inferior.php');?>