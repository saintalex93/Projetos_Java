<?php include_once('include/superiorEN.php');?>


      <div class="clear"></div>
    <div class="bannerOnda" >
        
    </div>
    <div id="titlePages">Lazer</div>
    <div class="margim">
    
    <section class="targ"></section>
    <section class="container">
    
    	<main class="main">
	
			
<section class="container">



		<div id="modal">
			<div id="box">
				<div class="close"><a href="#" onclick="closeIt()">X</a></div>
				<div class="rightArrow"><h1 onclick="next()">&raquo;</h1></div>
				<div class="leftArrow"><h1 onclick="prev()">&laquo;</h1></div>
			</div>


		</div>


	
<!-- 			<div class="box">
				


				<a href="" id="close">X</a>
		</div> -->
		<div class="galeriaFoto">
			<a href="#"><img src="../img/galeriaLazer1.JPG" alt="" onclick="onpenPhoto(this.src,0)"></a>
		</div>
		<div class="galeriaFoto">
			<a href="#"><img src="../img/galeriaLazer2.JPG" alt="" onclick="onpenPhoto(this.src,1)"></a>
		</div>
		<div class="galeriaFoto">
			<a href="#"><img src="../img/galeriaLazer3.JPG" alt="" onclick="onpenPhoto(this.src,2)"></a>
		</div>
		<div class="galeriaFoto">
			<a href="#"><img src="../img/galeriaLazer4.jpg" alt="" onclick="onpenPhoto(this.src,3)"></a>
		</div>
	
		<div class="clear"></div>
	</section>
	</main>
</section>
</div>


<script src ="../js/galleryRecreation.js">



</script>

<?php include_once('include/inferior.php');?>
    

    
    
    
    

